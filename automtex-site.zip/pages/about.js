
export default function About() {
  return (
    <div className="p-10 bg-black text-white min-h-screen">
      <h1 className="text-3xl font-bold mb-4">Sobre a AutomTeX</h1>
      <p className="text-gray-300">Somos especialistas em IA e automação para negócios modernos.</p>
    </div>
  );
}
