
export default function Contact() {
  return (
    <div className="p-10 bg-black text-white min-h-screen space-y-6">
      <h1 className="text-3xl font-bold">Contato</h1>
      <p>WhatsApp: 11 94129-1575</p>
      <p>Instagram: @negociolocal.assessoria</p>
      <p>Email: automtex@gmail.com</p>
    </div>
  );
}
