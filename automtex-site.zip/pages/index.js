
export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white flex flex-col items-center justify-center space-y-6">
      <h1 className="text-4xl font-bold">AutomTeX</h1>
      <p className="text-lg text-gray-300">Inovação e Inteligência Artificial para o seu negócio</p>
      <a href="/services" className="px-6 py-3 border rounded-xl">Ver Serviços</a>
    </main>
  );
}
