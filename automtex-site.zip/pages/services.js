
export default function Services() {
  return (
    <div className="p-10 bg-black text-white min-h-screen">
      <h1 className="text-3xl font-bold mb-4">Serviços</h1>
      <ul className="space-y-2 text-gray-300">
        <li>• Cartão Virtual Inteligente</li>
        <li>• Criação e otimização de WhatsApp Business</li>
        <li>• Perfil Google (Google Meu Negócio)</li>
        <li>• Tráfego Pago</li>
      </ul>
    </div>
  );
}
